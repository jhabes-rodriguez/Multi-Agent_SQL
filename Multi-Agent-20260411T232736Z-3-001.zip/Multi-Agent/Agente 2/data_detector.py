from typing import List, Dict, Any

def recommend_chart_type(data: List[Dict[str, Any]]) -> str:
    if not data or not isinstance(data, list):
        return "bar"
    
    first_row = data[0]
    num_cols = 0
    cat_cols = 0
    
    for key, value in first_row.items():
        if isinstance(value, (int, float)):
            num_cols += 1
        elif isinstance(value, str):
            cat_cols += 1
            
    if num_cols >= 2 and cat_cols == 0:
        return "scatter"
    elif cat_cols >= 1 and num_cols >= 1:
        return "bar"
    elif num_cols == 1 and cat_cols == 0:
        return "histogram"
    return "bar"
