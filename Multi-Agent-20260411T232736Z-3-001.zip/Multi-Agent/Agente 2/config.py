import os
from dotenv import load_dotenv
from pydantic_settings import BaseSettings

load_dotenv()

class Settings(BaseSettings):
    api_base_url: str = os.getenv("API_BASE_URL", "http://localhost:8000")
    groq_api_key: str = os.getenv("GROQ_API_KEY", "")
    groq_model: str = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
    port: int = int(os.getenv("PORT", 8080))
    
    class Config:
        env_file = ".env"

settings = Settings()
