import uvicorn
import json
import os
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from config import settings
from api_client import fetch_datasets, fetch_query_history, run_query
from explainer import interpret_message, generate_explanation
from chart_generator import generate_chart_config
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="Agent 3: Visualizer & Explainer")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    message: str

@app.post("/api/process")
async def process_message(request: ChatRequest):
    intent = await interpret_message(request.message)
    
    data = await run_query(request.message)
    
    if isinstance(data, dict) and "error" in data:
        return {"error": data["error"]}
        
    chart_config = generate_chart_config(data, intent)
    
    data_summary = json.dumps(data[:5]) if isinstance(data, list) else str(data)
    explanation = await generate_explanation(data_summary, request.message)
    
    return {
        "intent": intent,
        "chart_config": chart_config,
        "explanation": explanation
    }

@app.get("/api/datasets")
async def get_datasets():
    return await fetch_datasets()

# Crear frontend dir temporalmente si no existe para que fastapi mount no falle
os.makedirs("frontend", exist_ok=True)
app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")

if __name__ == "__main__":
    uvicorn.run("server:app", host="0.0.0.0", port=settings.port, reload=True)
