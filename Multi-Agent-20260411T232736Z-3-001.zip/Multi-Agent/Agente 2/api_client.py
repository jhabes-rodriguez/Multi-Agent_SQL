import httpx
from typing import Dict, Any, List
from config import settings

async def fetch_datasets() -> List[Dict[str, Any]]:
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(f"{settings.api_base_url}/datasets/list")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"Error fetching datasets: {e}")
            return [{"id": "titanic", "name": "Titanic", "rows": 891}, {"id": "health", "name": "Health Data", "rows": 1024}] # Fallback para dev

async def fetch_query_history() -> List[Dict[str, Any]]:
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(f"{settings.api_base_url}/queries/history")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return []

async def fetch_latest_insight() -> Dict[str, Any]:
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(f"{settings.api_base_url}/insights/latest")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {}

async def run_query(query: str) -> Dict[str, Any]:
    # Este endpoint en Agent 2 nos daría los datos
    async with httpx.AsyncClient() as client:
        try:
            # Simplificación: si la API no está, devolvemos un mock para que no falle frontend
            response = await client.post(f"{settings.api_base_url}/queries/run", json={"query": query})
            response.raise_for_status()
            return response.json()
        except Exception as e:
            # Fallback mock data para dev local si Agent 2 no está disponible
            return [
                {"category": "A", "value": 10},
                {"category": "B", "value": 25},
                {"category": "C", "value": 15},
                {"category": "D", "value": 30}
            ]
