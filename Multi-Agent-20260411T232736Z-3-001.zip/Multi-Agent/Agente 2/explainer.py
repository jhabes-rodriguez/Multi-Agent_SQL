import json
from groq import AsyncGroq
from config import settings

# Ignorar si no hay API_KEY de momento o arrojar warning
try:
    client = AsyncGroq(api_key=settings.groq_api_key)
except Exception:
    client = None

async def interpret_message(user_message: str) -> dict:
    """
    Convierte el texto libre en JSON estructurado.
    Formato: {"action": "graph|explain|compare|list", "dataset": "nombre", "column": "columna", "chart_type": "bar|line|scatter|histogram|pie"}
    """
    if not client:
        # Mock si no hay groq disponible por key
        return {"action": "graph", "dataset": "mock", "column": "mock_col", "chart_type": "bar"}

    prompt = f"""
    Eres un asistente de análisis de datos en un sistema multi-agente. Identifica la intención de análisis de datos a partir del mensaje.
    Extrae la siguiente información y devuélvela estríctamente como un objeto JSON usando las siguientes llaves:
    - action: uno de ["graph", "explain", "compare", "list"]
    - dataset: el nombre del dataset mencionado (si no especifica uno, usa null)
    - column: la columna o métrica específica mencionada (si se infiere, de otra forma null)
    - chart_type: el tipo de gráfica explícitamente pedida, uno de ["bar", "line", "scatter", "histogram", "pie"]. Si no se dice, null.

    Mensaje del usuario: "{user_message}"
    """
    
    try:
        chat_completion = await client.chat.completions.create(
            messages=[{"role": "user", "content": prompt}],
            model=settings.groq_model,
            response_format={"type": "json_object"},
            temperature=0.0
        )
        response_text = chat_completion.choices[0].message.content
        return json.loads(response_text)
    except Exception as e:
        print(f"Error iterpretando mensaje: {e}")
        return {"action": "graph", "dataset": None, "column": None, "chart_type": "bar"}

async def generate_explanation(data_summary: str, original_query: str) -> str:
    """
    Genera explicación en español con insights, máximo 3 párrafos.
    """
    if not client:
        return "No processable sin llave de API."

    prompt = f"""
    Eres un analista de datos experto. Explica brevemente los siguientes datos.
    Da insights de valor y explica patrones (comenzar directo al grano, sin saludos).
    Máximo 3 párrafos. Responde siempre en español.
    
    Petición original: "{original_query}"
    Resumen de datos: {data_summary}
    """
    
    try:
        chat_completion = await client.chat.completions.create(
            messages=[{"role": "user", "content": prompt}],
            model=settings.groq_model,
            temperature=0.7,
            max_tokens=600
        )
        return chat_completion.choices[0].message.content
    except Exception as e:
        return f"No se pudo generar una explicación debido a un error: {e}"
