document.addEventListener("DOMContentLoaded", () => {
    const chatForm = document.getElementById('chat-form');
    const userInput = document.getElementById('user-input');
    const chatMessages = document.getElementById('chat-messages');
    const datasetsList = document.getElementById('datasets-list');
    
    const API_URL = '/api';

    fetchDatasets();

    chatForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const text = userInput.value.trim();
        if (!text) return;

        appendMessage(text, 'user');
        userInput.value = '';

        const typingId = showTypingIndicator();

        try {
            const response = await fetch(`${API_URL}/process`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: text })
            });

            if (!response.ok) throw new Error('Error al conectar con el servidor.');
            
            const data = await response.json();
            removeTypingIndicator(typingId);
            
            if (data.error) {
                appendMessage(`Error: ${data.error}`, 'system');
            } else {
                appendSystemMessageWithChart(data.explanation, data.chart_config);
                saveHistory(text);
            }
        } catch (error) {
            removeTypingIndicator(typingId);
            appendMessage(`Hubo un error de red o en el servidor. Revisa si la API corre en el 8080: ${error.message}`, 'system');
        }
    });

    async function fetchDatasets() {
        try {
            const response = await fetch(`${API_URL}/datasets`);
            if (!response.ok) return;
            const datasets = await response.json();
            
            if (datasets && datasets.length > 0) {
                datasetsList.innerHTML = '';
                datasets.forEach(ds => {
                    const li = document.createElement('li');
                    li.innerHTML = `<span class="status-dot"></span>${ds.name || ds.id}`;
                    datasetsList.appendChild(li);
                });
            } else {
                datasetsList.innerHTML = '<li><span class="text-muted small">No hay datasets</span></li>';
            }
        } catch (error) {
            datasetsList.innerHTML = '<li><span class="text-muted small">Error al cargar datos</span></li>';
        }
    }

    function saveHistory(query) {
        let history = JSON.parse(localStorage.getItem('agent3_history') || '[]');
        history.unshift(query);
        if(history.length > 10) history = history.slice(0, 10);
        localStorage.setItem('agent3_history', JSON.stringify(history));
        renderHistory();
    }

    function renderHistory() {
        const hList = document.getElementById('history-list');
        const history = JSON.parse(localStorage.getItem('agent3_history') || '[]');
        
        if (history.length > 0) {
            hList.innerHTML = '';
            history.forEach(item => {
                const li = document.createElement('li');
                li.innerHTML = `💬 <span class="small" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 200px;">${item}</span>`;
                li.onclick = () => { userInput.value = item; userInput.focus(); };
                hList.appendChild(li);
            });
        }
    }
    
    renderHistory();

    function appendMessage(text, sender) {
        const div = document.createElement('div');
        div.className = `message ${sender}-message slide-in`;
        
        const content = document.createElement('div');
        content.className = 'message-content';
        
        const paragraphs = text.split('\n\n').filter(p => p.trim());
        if (paragraphs.length > 0) {
            paragraphs.forEach(p => {
                const pTag = document.createElement('p');
                pTag.textContent = p;
                content.appendChild(pTag);
            });
        } else {
            const pTag = document.createElement('p');
            pTag.textContent = text;
            content.appendChild(pTag);
        }

        div.appendChild(content);
        chatMessages.appendChild(div);
        scrollToBottom();
    }

    function appendSystemMessageWithChart(explanation, chartConfig) {
        const div = document.createElement('div');
        div.className = 'message system-message slide-in';
        
        const content = document.createElement('div');
        content.className = 'message-content';
        
        if (explanation) {
            const paragraphs = explanation.split('\n\n').filter(p => p.trim());
            paragraphs.forEach(p => {
                const pTag = document.createElement('p');
                pTag.textContent = p;
                content.appendChild(pTag);
            });
        }

        if (chartConfig && chartConfig.data && chartConfig.data.length > 0) {
            const chartDiv = document.createElement('div');
            const chartId = `chart-${Date.now()}`;
            chartDiv.id = chartId;
            chartDiv.className = 'chart-container';
            content.appendChild(chartDiv);
            
            div.appendChild(content);
            chatMessages.appendChild(div);
            
            // Plot con Plotly
            Plotly.newPlot(chartId, chartConfig.data, chartConfig.layout, {responsive: true, displayModeBar: false});
            
            // Add resize listener to this specific plot
            window.addEventListener('resize', () => {
                Plotly.Plots.resize(chartId);
            });
        } else {
            div.appendChild(content);
            chatMessages.appendChild(div);
        }
        
        scrollToBottom();
    }

    function showTypingIndicator() {
        const id = `typing-${Date.now()}`;
        const html = `
            <div id="${id}" class="typing-indicator slide-in">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        `;
        chatMessages.insertAdjacentHTML('beforeend', html);
        scrollToBottom();
        return id;
    }

    function removeTypingIndicator(id) {
        const el = document.getElementById(id);
        if (el) el.remove();
    }

    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
});
