from typing import List, Dict, Any
from data_detector import recommend_chart_type

def generate_chart_config(data: List[Dict[str, Any]], intent: dict) -> dict:
    if not data or not isinstance(data, list) or len(data) == 0:
        return {}

    chart_type_intent = intent.get("chart_type")
    
    if not chart_type_intent or chart_type_intent not in ["bar", "line", "scatter", "histogram", "pie"]:
        chart_type = recommend_chart_type(data)
    else:
        chart_type = chart_type_intent
        
    first_row = data[0]
    
    num_cols = [k for k, v in first_row.items() if isinstance(v, (int, float))]
    cat_cols = [k for k, v in first_row.items() if isinstance(v, str)]
    
    x_col = cat_cols[0] if cat_cols else (num_cols[0] if len(num_cols) > 0 else list(first_row.keys())[0])
    y_col = num_cols[0] if num_cols else (cat_cols[1] if len(cat_cols) > 1 else list(first_row.keys())[-1])
    
    if intent.get("column") and intent.get("column") in first_row.keys():
        col = intent["column"]
        if col in num_cols: y_col = col
        elif col in cat_cols: x_col = col

    x_data = [row.get(x_col) for row in data]
    y_data = [row.get(y_col) for row in data]
    
    trace = {}
    
    if chart_type == "bar":
        trace = {"type": "bar", "x": x_data, "y": y_data}
    elif chart_type == "line":
        trace = {"type": "scatter", "mode": "lines+markers", "x": x_data, "y": y_data}
    elif chart_type == "scatter":
        trace = {"type": "scatter", "mode": "markers", "x": x_data, "y": y_data}
    elif chart_type == "histogram":
        trace = {"type": "histogram", "x": y_data if num_cols else x_data}
    elif chart_type == "pie":
        trace = {"type": "pie", "labels": x_data, "values": y_data}

    config = {
        "data": [trace],
        "layout": {
            "title": {"text": f"{y_col} vs {x_col}" if chart_type != "histogram" else f"Histograma de {x_col if not num_cols else y_col}", "font": {"color": "#f1f5f9"}},
            "paper_bgcolor": "#16213e",
            "plot_bgcolor": "#16213e",
            "colorway": ["#7c3aed", "#10b981", "#f59e0b", "#ef4444", "#3b82f6"],
            "font": {"color": "#94a3b8", "family": "Inter, sans-serif"},
            "xaxis": {"gridcolor": "#1e293b", "zerolinecolor": "#1e293b"},
            "yaxis": {"gridcolor": "#1e293b", "zerolinecolor": "#1e293b"},
            "margin": {"l": 40, "r": 20, "t": 50, "b": 40}
        }
    }
    return config
