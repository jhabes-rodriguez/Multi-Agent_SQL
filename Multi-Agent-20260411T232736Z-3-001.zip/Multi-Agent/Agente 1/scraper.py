import json
import re
import urllib.parse
import time
import requests
from bs4 import BeautifulSoup
from config import HEADERS

def search_kaggle_datasets(query, max_results=5):
    """
    Busca datasets en Kaggle usando web scraping simple.
    Retorna una lista de diccionarios con la información de cada dataset.
    """
    encoded_query = urllib.parse.quote_plus(query)
    url = f"https://www.kaggle.com/datasets?search={encoded_query}&sort=votes"
    
    # Se agrega delay para no ser bloqueados rápidamente
    time.sleep(1)
    
    response = requests.get(url, headers=HEADERS)
    if response.status_code != 200:
        raise Exception(f"Error al conectar con Kaggle: {response.status_code}")
        
    soup = BeautifulSoup(response.text, 'lxml')
    datasets = []
    
    # Kaggle suele cargar sus datos iniciales en un script JS en el DOM.
    # Vamos a crear una estrategia dual: Buscar en el HTML y buscar en el script JSON.
    
    # Estrategia 1: Extraer data directamente de `__KAGGLE_INITIAL_STATE__` si existe.
    script_data = soup.find('script', string=re.compile('window.__INITIAL_STATE__'))
    if script_data:
        try:
            # Extraer el JSON del script
            match = re.search(r'window.__INITIAL_STATE__\s*=\s*({.*?});', script_data.string)
            if match:
                data = json.loads(match.group(1))
                # La estructura interna puede variar, buscaremos recursivamente resultados
                # Esta parte requeriría explorar el JSON si falla la Estrategia 2.
                pass
        except Exception:
            pass
            
    # Estrategia 2: Búsqueda basada en nodos del DOM (<a> tags que parezcan datasets)
    # Los datasets suelen tener links formato: /datasets/autor/nombre-dataset
    links = soup.find_all('a', href=re.compile(r'^/datasets/[^/]+/[^/]+$'))
    
    seen_urls = set()
    for link in links:
        href = link.get('href')
        if href in seen_urls:
            continue
            
        # Kaggle minifica sus clases, buscamos texto dentro de los divs del link
        text_content = link.get_text(separator='|', strip=True).split('|')
        
        # Filtramos links cortos que puedan ser botones "Download", etc.
        if len(text_content) < 2:
            continue
            
        # Inferimos datos basados en la estructura típica de la tarjeta
        # ej: "Nombre del Dataset", "Autor", "Update", "Votos"
        title = text_content[0]
        author = href.split('/')[2] # /datasets/AUTHOR/dataset-name
        
        # Extraemos votos buscando números (Kaggle suele mostrarlos)
        votes = 0
        for text in text_content:
            if text.isdigit():
                votes = int(text)
            elif 'k' in text.lower():
                try:
                    num = float(text.lower().replace('k', ''))
                    votes = int(num * 1000)
                except ValueError:
                    pass
                    
        # Descripción: Kaggle a veces no muestra una descripción larga en la lista, usamos el título como base o iteramos.
        desc = " ".join(text_content[1:3]) if len(text_content) > 1 else title
        
        datasets.append({
            'name': title,
            'author': author,
            'description': f"Dataset extraído de Kaggle: {desc}".strip()[:200], # Trucamos para seguridad
            'source_url': f"https://www.kaggle.com{href}",
            'download_url': f"https://www.kaggle.com{href}/download",
            'votes': votes
        })
        
        seen_urls.add(href)
        
        if len(datasets) >= max_results:
            break
            
    # Ordenar por votos, por si la extracción no fue perfectly sorteda ya por la URL
    datasets.sort(key=lambda x: x.get('votes', 0), reverse=True)
    return datasets[:max_results]

# Script de prueba rápida (solo se ejecuta si corremos scraper.py directamente)
if __name__ == "__main__":
    from rich.console import Console
    console = Console()
    console.print("[yellow]Probando scraper con query: 'health datasets'[/yellow]")
    res = search_kaggle_datasets("health datasets", max_results=3)
    console.print(res)
