import os
import sys
import re
from rich.console import Console
from rich.prompt import Prompt
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from groq import Groq

from config import GROQ_API_KEY, GROQ_MODEL
from scraper import search_kaggle_datasets
from downloader import download_and_extract_dataset
from uploader import upload_to_central_api

console = Console()

def extract_intent_with_groq(user_input):
    """
    Usa Groq (Llama-3) para extraer el término de búsqueda en inglés 
    y el número de datasets a procesar.
    """
    if not GROQ_API_KEY:
        console.print("[yellow]Advertencia: No se encontró GROQ_API_KEY. Usando búsqueda normal.[/yellow]")
        return user_input, 3

    client = Groq(api_key=GROQ_API_KEY)
    
    prompt = f"""
    Eres un asistente para un scraper de Kaggle. El usuario te dará una orden coloquial en español.
    Tu tarea es traducir el término de búsqueda a inglés para Kaggle, y extraer cuántos datasets quiere (número entero).
    
    Orden del usuario: "{user_input}"
    
    Debes responder ÚNICAMENTE en el siguiente formato, sin texto extra ni markdown:
    SEARCH_TERM|NUMBER
    
    Si no especifica un número, asume 3.
    Por ejemplo, si dice "busca datasets de salud cardiovascular, baja 2", debes responder:
    cardiovascular health|2
    """
    
    try:
        completion = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
            max_tokens=20
        )
        
        response_text = completion.choices[0].message.content.strip()
        parts = response_text.split('|')
        query = parts[0].strip()
        num_datasets = int(parts[1].strip()) if len(parts) > 1 and parts[1].strip().isdigit() else 3
        
        return query, num_datasets
        
    except Exception as e:
        console.print(f"[red]Error procesando intención con Groq: {e}\nUsando texto base.[/red]")
        # Fallback de extracción básica
        return user_input, 3

def main():
    console.print(Panel.fit("[bold green]Agent 1: Kaggle Scraper 🕸️[/bold green]\nListo para buscar, descargar y enviar datasets a la API Central.", border_style="green"))
    
    # 1. Obtener orden del usuario
    user_input = Prompt.ask("\n[bold cyan]¿Qué deseas buscar en Kaggle?[/bold cyan]\n(Ej. 'busca datasets de salud, descarga 2')")
    
    if not user_input.strip():
        console.print("[red]Búsqueda vacía. Saliendo...[/red]")
        sys.exit(0)
        
    # 2. Extender con Groq
    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True) as progress:
        progress.add_task("[yellow]Interpretando orden con Groq (LLM)...", total=None)
        search_query, max_results = extract_intent_with_groq(user_input)
        
    console.print(f"[green]✔ Búsqueda interpretada:[/green] [bold]'{search_query}'[/bold] (Máx: {max_results} datasets)")
    
    # 3. Web Scraping
    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True) as progress:
        progress.add_task(f"[cyan]Scrapeando Kaggle por '{search_query}'...", total=None)
        try:
            datasets = search_kaggle_datasets(search_query, max_results=max_results)
        except Exception as e:
            console.print(f"[bold red]Error en web scraping: {e}[/bold red]")
            sys.exit(1)
            
    if not datasets:
        console.print("[bold yellow]No se encontraron datasets para esa búsqueda. Kaggle podría estar bloqueando el IP o modificó su HTML.[/bold yellow]")
        sys.exit(0)
    
    # Mostrar resultados en tabla
    table = Table(title="Datasets Encontrados en Kaggle", show_header=True, header_style="bold magenta")
    table.add_column("Nombre", style="cyan", max_width=40)
    table.add_column("Autor", style="blue")
    table.add_column("Votos", justify="right", style="green")
    
    for ds in datasets:
        table.add_row(ds['name'], ds['author'], str(ds['votes']))
        
    console.print(table)
    
    # 4 & 5. Descargar y Subir
    uploaded_results = []
    
    for i, ds in enumerate(datasets):
        console.print(f"\n[bold blue]Procesando ({i+1}/{len(datasets)}): {ds['name']}[/bold blue]")
        
        extracted_file = None
        try:
            # Descarga y extracción
            extracted_file = download_and_extract_dataset(ds)
            console.print(f"[green]✔ Extraído exitosamente: {os.path.basename(extracted_file)}[/green]")
            
            # Subida a la API Central
            with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True) as progress:
                progress.add_task("[yellow]Subiendo a la API Central...", total=None)
                api_response = upload_to_central_api(ds, extracted_file)
            
            if api_response and "status" in api_response and api_response["status"] == "skipped":
                console.print("[yellow]Subida cancelada por el usuario.[/yellow]")
                uploaded_results.append((ds['name'], "Ignorado"))
            else:
                console.print(f"[green]✔ Dataset '{ds['name']}' subido exitosamente a la API.[/green]")
                uploaded_results.append((ds['name'], "Subido OK"))
                
        except Exception as e:
            console.print(f"[bold red]✖ Error procesando '{ds['name']}':[/bold red] {e}")
            uploaded_results.append((ds['name'], "Error"))
        finally:
            # Clean up the file if exists but downloader.py usually deletes temp dir
            # Wait, the extracted file is inside a temp directory! 
            # I must clean that root temp dir up after uploading it.
            if extracted_file:
                temp_dir = os.path.dirname(extracted_file)
                # Keep finding parent until it's 'kaggle_tmp_' to remove it safely
                while "kaggle_tmp_" not in os.path.basename(temp_dir) and os.path.dirname(temp_dir) != temp_dir:
                    temp_dir = os.path.dirname(temp_dir)
                import shutil
                if "kaggle_tmp_" in os.path.basename(temp_dir) and os.path.exists(temp_dir):
                    shutil.rmtree(temp_dir)
                    
    # Resumen final
    console.print(Panel.fit("[bold]Resumen de la operación[/bold]", border_style="cyan"))
    summary_table = Table(show_header=False)
    for res in uploaded_results:
        color = "green" if "OK" in res[1] else "yellow" if "Ignorado" in res[1] else "red"
        summary_table.add_row(res[0], f"[{color}]{res[1]}[/{color}]")
    console.print(summary_table)
    console.print("\n[bold green]Agente 1 ha finalizado su labor. 🕸️[/bold green]")

if __name__ == "__main__":
    main()
