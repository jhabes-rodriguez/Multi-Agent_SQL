import os
from dotenv import load_dotenv

# Cargar variables desde el archivo .env
load_dotenv()

API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:8000")
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "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")
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")

KAGGLE_USERNAME = os.getenv("KAGGLE_USERNAME", "")
KAGGLE_PASSWORD = os.getenv("KAGGLE_PASSWORD", "")
KAGGLE_COOKIE = os.getenv("KAGGLE_COOKIE", "")

# Cabeceras por defecto para simular un navegador
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"
}
