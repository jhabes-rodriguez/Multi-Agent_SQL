import requests
from config import API_BASE_URL
from rich.console import Console
from rich.prompt import Confirm
import os

console = Console()

def upload_to_central_api(dataset_info, file_path):
    """
    Sube el archivo extraído a la API Central (Agent 2) con la metadata.
    """
    url = f"{API_BASE_URL}/datasets/upload"
    
    data = {
        'name': dataset_info.get('name', 'Unknown'),
        'description': dataset_info.get('description', ''),
        'source_url': dataset_info.get('source_url', ''),
        'votes': dataset_info.get('votes', 0)
    }
    
    try:
        # Abrimos el archivo en modo binario
        with open(file_path, 'rb') as f:
            files = {'file': (os.path.basename(file_path), f)}
            response = requests.post(url, files=files, data=data)
            
            # Asumimos que si devuelve un error del tipo 409 es porque ya existe.
            if response.status_code == 409:
                console.print(f"[yellow]El dataset '{data['name']}' ya existe en la API Central.[/yellow]")
                overwrite = Confirm.ask("¿Deseas intentar sobreescribirlo?")
                if overwrite:
                    # Agregamos una bandera de sobreescritura (si la API lo soportara)
                    data['overwrite'] = 'True'
                    # Tenemos que reabrir el archivo porque el puntero de f ya avanzó en el request fallido
                    with open(file_path, 'rb') as f_retry:
                        files_retry = {'file': (os.path.basename(file_path), f_retry)}
                        response_retry = requests.post(url, files=files_retry, data=data)
                        response_retry.raise_for_status()
                        return response_retry.json()
                else:
                    return {"status": "skipped", "message": "Ignorado por el usuario"}
            
            # Si el backend falla por no tener conexión
            response.raise_for_status()
            return response.json()
            
    except requests.exceptions.ConnectionError:
        raise Exception(f"No se pudo conectar a la API Central en {API_BASE_URL}. ¿Está encendido el Agente 2?")
    except requests.exceptions.HTTPError as err:
        raise Exception(f"HTTP Error de la API Central: {err.response.status_code} - {err.response.text}")

def register_metadata_only(dataset_info):
    """
    Alternativa que usa la ruta register si solo se requiere enviar metadata.
    (Utilizado por si la arquitectura del Agente 2 requiere registro previo)
    """
    url = f"{API_BASE_URL}/datasets/register"
    try:
        response = requests.post(url, json=dataset_info)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        console.print(f"[red]Error registrando metadata: {str(e)}[/red]")
        return None
