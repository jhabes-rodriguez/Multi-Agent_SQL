import os
import shutil
import zipfile
import tempfile
import requests
from config import HEADERS, KAGGLE_USERNAME, KAGGLE_PASSWORD, KAGGLE_COOKIE
from rich.progress import Progress

def setup_kaggle_session():
    """
    Crea una sesión de requests e intenta autenticarse en Kaggle.
    Si proveemos KAGGLE_COOKIE en .env, usa esa cookie directamente (recomendado
    para evitar reCAPTCHA o Cloudflare).
    """
    session = requests.Session()
    session.headers.update(HEADERS)
    
    if KAGGLE_COOKIE:
        # Usamos la cookie proveída manualmente por el usuario
        session.headers.update({'Cookie': KAGGLE_COOKIE})
        return session
        
    if KAGGLE_USERNAME and KAGGLE_PASSWORD:
        # Intento de login web manual (suele fallar debido a anti-bot protections)
        login_url = "https://www.kaggle.com/account/login"
        try:
            # Primero obtener tokens como XSRF-TOKEN
            session.get(login_url) 
            xsrf = session.cookies.get('XSRF-TOKEN', '')
            if xsrf:
                session.headers.update({'X-XSRF-TOKEN': xsrf})
            
            # Nota: El payload real de Kaggle en la UI usa Next.js auth o reCAPTCHA.
            # Hacemos un intento de POST estándar (best-effort).
            payload = {
                'username': KAGGLE_USERNAME,
                'password': KAGGLE_PASSWORD
            }
            # En un caso totalmente real sin SDK, la API a menudo requiere interactuar
            # como web o usar Basic Auth a `/api/v1` pero el requerimiento prohíbe SDK.
            # Kaggle bloquea los bots, así que esto es un intento formativo.
            res = session.post(login_url, data=payload)
        except Exception:
            pass
            
    return session

def download_and_extract_dataset(dataset_info):
    """
    Descarga el dataset dado un diccionario 'dataset_info' devuelto por el scraper.
    Retorna la ruta al archivo CSV o JSON extraído, o None si falla.
    """
    download_url = dataset_info['download_url']
    tmp_dir = tempfile.mkdtemp(prefix="kaggle_tmp_")
    zip_path = os.path.join(tmp_dir, "dataset.zip")
    
    session = setup_kaggle_session()
    
    try:
        # Usamos stream=True para poder mostrar barra de progreso
        response = session.get(download_url, stream=True)
        if response.status_code == 403:
            raise Exception("Acceso denegado. Kaggle bloqueó la descarga (probablemente falten cookies válidas en KAGGLE_COOKIE).")
        response.raise_for_status()
        
        total_size = int(response.headers.get('content-length', 0))
        
        with Progress() as progress:
            task = progress.add_task(f"[cyan]Descargando {dataset_info['name']}...", total=total_size or None)
            
            with open(zip_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        if total_size:
                            progress.update(task, advance=len(chunk))
        
        # Verificar si realmente es un zip (Kaggle puede redirigir a una página de login HTML)
        if not zipfile.is_zipfile(zip_path):
            raise Exception("El archivo descargado no es un ZIP válido. Es posible que Kaggle te esté pidiendo iniciar sesión.")
            
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(tmp_dir)
            
        os.remove(zip_path) # Limpiar el ZIP original
        
        # Buscar CSV o JSON en el contenido extraído
        for root, dirs, files in os.walk(tmp_dir):
            for file in files:
                if file.endswith('.csv') or file.endswith('.json'):
                    return os.path.join(root, file)
                    
        raise Exception("No se encontraron archivos CSV o JSON en el dataset descargado.")
        
    except Exception as e:
        # En caso de fallar, limpiamos la carpeta
        cleanup_temp_dir(tmp_dir)
        raise e

def cleanup_temp_dir(dir_path):
    """Elimina el directorio temporal donde se extrajeron los archivos."""
    if dir_path and os.path.exists(dir_path):
        shutil.rmtree(dir_path)
