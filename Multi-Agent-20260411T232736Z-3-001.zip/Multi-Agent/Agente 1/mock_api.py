from fastapi import FastAPI, UploadFile, Form, File, HTTPException
import uvicorn
import os

app = FastAPI(title="Mock Central API (Agent 2 Emulator)")

# Carpeta donde nuestro servidor falso guardará los datasets
UPLOAD_DIR = "mock_uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.post("/datasets/upload")
async def upload_dataset(
    file: UploadFile = File(...),
    name: str = Form(...),
    description: str = Form(""),
    source_url: str = Form(""),
    votes: int = Form(0),
    overwrite: str = Form("False")
):
    print(f"\n[API Central Mock] Recibiendo petición de subida...")
    print(f" - Nombre: {name}")
    print(f" - Archivo: {file.filename}")
    print(f" - Votos: {votes}")
    
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    
    # Simulamos el error 409 si el archivo ya existe y el usuario no forzó la sobreescritura
    if os.path.exists(file_path) and overwrite == "False":
        print(f"[API Central Mock] ❌ Error: El dataset '{name}' ya existe. Devolviendo HTTP 409.")
        raise HTTPException(status_code=409, detail="Dataset already exists")
        
    # Guardamos el archivo y simulamos subida exitosa
    try:
        content = await file.read()
        with open(file_path, "wb") as f:
            f.write(content)
        print(f"[API Central Mock] ✅ Archivo '{file.filename}' guardado exitosamente en /{UPLOAD_DIR}")
        return {"status": "success", "message": f"Dataset {name} subido correctamente", "saved_path": file_path}
    except Exception as e:
        print(f"[API Central Mock] ❌ Error de servidor: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.post("/datasets/register")
async def register_dataset(metadata: dict):
    print(f"\n[API Central Mock] Recibiendo registro (sólo metadata): {metadata}")
    return {"status": "success", "message": "Metadata registrada"}

if __name__ == "__main__":
    print(f"Levantando Mock API Central en http://localhost:8000 ...")
    uvicorn.run(app, host="127.0.0.1", port=8000)
