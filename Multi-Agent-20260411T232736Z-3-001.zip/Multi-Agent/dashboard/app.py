"""
dashboard/app.py
================
FastAPI backend del dashboard web unificado.
- Sirve el HTML del dashboard
- Arranca/detiene cada agente como subprocess
- Hace streaming de logs via WebSocket
- Expone el estado de todos los servicios
"""

import os
import sys
import subprocess
import threading
import asyncio
from typing import Optional
from collections import deque

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

# Asegurar que el root del proyecto esté en el path
ROOT = os.path.dirname(os.path.dirname(__file__))
sys.path.insert(0, ROOT)

from orchestrator.config import config as orch_config

app = FastAPI(title="Multi-Agent Dashboard")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─────────────────────────────────────────────────────────────────────────────
# Estado global de procesos
# ─────────────────────────────────────────────────────────────────────────────

_procs: dict[str, Optional[subprocess.Popen]] = {
    "api": None,
    "agent1": None,
    "agent2": None,
    "agent3": None,
}

# Buffer de logs por servicio (últimas 300 líneas)
_logs: dict[str, deque] = {
    k: deque(maxlen=300) for k in _procs
}

# Clientes WebSocket suscritos por servicio
_ws_clients: dict[str, list] = {
    k: [] for k in _procs
}


def _status(key: str) -> str:
    proc = _procs.get(key)
    if proc is None:
        return "stopped"
    if proc.poll() is None:
        return "running"
    return "error"


def _build_env(extra: dict = None) -> dict:
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    if extra:
        env.update(extra)
    return env


async def _broadcast(key: str, message: str):
    """Envía un mensaje a todos los WebSocket suscritos a ese servicio."""
    dead = []
    for ws in _ws_clients[key]:
        try:
            await ws.send_text(message)
        except Exception:
            dead.append(ws)
    for ws in dead:
        _ws_clients[key].remove(ws)


def _stream_proc(key: str, proc: subprocess.Popen):
    """Lee stdout+stderr de un proceso en un thread y guarda/broadcast los logs."""
    loop = asyncio.new_event_loop()

    def read_stream(stream):
        try:
            for raw in stream:
                try:
                    line = raw.decode("utf-8", errors="replace").rstrip()
                except Exception:
                    line = repr(raw)
                _logs[key].append(line)
                asyncio.run_coroutine_threadsafe(_broadcast(key, line), loop)
        except Exception:
            pass

    loop.run_in_executor(None, read_stream, proc.stdout)
    loop.run_in_executor(None, read_stream, proc.stderr)
    loop.run_forever()


def _launch_stream(key: str, cmd: list, cwd: str, extra_env: dict = None):
    """Arranca un subprocess y conecta el streaming de logs."""
    env = _build_env(extra_env)
    proc = subprocess.Popen(
        cmd,
        cwd=cwd,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    _procs[key] = proc
    _logs[key].clear()
    t = threading.Thread(target=_stream_proc, args=(key, proc), daemon=True)
    t.start()
    return proc


# ─────────────────────────────────────────────────────────────────────────────
# Endpoints de control
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/status")
def status_all():
    return {
        k: _status(k) for k in _procs
    }


@app.post("/start/{service}")
def start_service(service: str):
    if service not in _procs:
        return JSONResponse({"error": "Servicio no reconocido"}, status_code=400)

    if _status(service) == "running":
        return {"ok": False, "msg": f"{service} ya está corriendo"}

    if service == "api":
        _launch_stream("api", [sys.executable, "start_api.py"], ROOT, {
            "PORT": str(orch_config.api_port),
            "DATABASE_PATH": orch_config.db_path,
            "DATASETS_DIR": orch_config.datasets_dir,
            "CACHE_DB": orch_config.cache_db,
        })

    elif service == "agent1":
        agent_dir = os.path.join(ROOT, "Agente 1")
        _launch_stream("agent1", [sys.executable, "main.py"], agent_dir,
                       orch_config.agent1.as_env_dict())

    elif service == "agent2":
        _launch_stream("agent2", [sys.executable, "start_agent2.py"], ROOT,
                       orch_config.agent2.as_env_dict())

    elif service == "agent3":
        agent_dir = os.path.join(ROOT, "Agente 3")
        env = orch_config.agent3.as_env_dict()
        env["PORT"] = str(orch_config.agent3.port or 8080)
        _launch_stream("agent3", [sys.executable, "server.py"], agent_dir, env)

    return {"ok": True, "msg": f"{service} iniciado"}


@app.post("/stop/{service}")
def stop_service(service: str):
    if service not in _procs:
        return JSONResponse({"error": "Servicio no reconocido"}, status_code=400)

    proc = _procs.get(service)
    if proc and proc.poll() is None:
        proc.terminate()
        _logs[service].append(f"[Sistema] {service} detenido manualmente.")
    _procs[service] = None
    return {"ok": True, "msg": f"{service} detenido"}


@app.get("/logs/{service}")
def get_logs(service: str):
    if service not in _logs:
        return JSONResponse({"error": "Servicio no reconocido"}, status_code=400)
    return {"logs": list(_logs[service])}


@app.get("/keys")
def get_keys():
    """Devuelve la configuración de API keys (enmascaradas)."""
    def mask(key: str) -> str:
        if len(key) > 12:
            return key[:8] + "..." + key[-4:]
        return "NO CONFIGURADA"

    return {
        "agent1": {
            "name": orch_config.agent1.name,
            "key": mask(orch_config.agent1.groq_api_key),
            "model": orch_config.agent1.groq_model,
            "api_url": orch_config.agent1.api_base_url,
            "valid": orch_config.agent1.is_valid(),
        },
        "agent2": {
            "name": orch_config.agent2.name,
            "key": mask(orch_config.agent2.groq_api_key),
            "model": orch_config.agent2.groq_model,
            "api_url": orch_config.agent2.api_base_url,
            "valid": orch_config.agent2.is_valid(),
        },
        "agent3": {
            "name": orch_config.agent3.name,
            "key": mask(orch_config.agent3.groq_api_key),
            "model": orch_config.agent3.groq_model,
            "api_url": orch_config.agent3.api_base_url,
            "valid": orch_config.agent3.is_valid(),
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# WebSocket de logs en tiempo real
# ─────────────────────────────────────────────────────────────────────────────

@app.websocket("/ws/logs/{service}")
async def ws_logs(websocket: WebSocket, service: str):
    if service not in _ws_clients:
        await websocket.close(code=1008)
        return

    await websocket.accept()
    _ws_clients[service].append(websocket)

    # Enviar historial acumulado
    for line in list(_logs[service]):
        await websocket.send_text(line)

    try:
        while True:
            await asyncio.sleep(1)
            # Mantener viva la conexión
            if _procs.get(service) and _procs[service].poll() is not None:
                await websocket.send_text(f"[Sistema] Proceso terminó con código {_procs[service].returncode}")
                break
    except WebSocketDisconnect:
        pass
    finally:
        if websocket in _ws_clients[service]:
            _ws_clients[service].remove(websocket)


# ─────────────────────────────────────────────────────────────────────────────
# Servir el dashboard HTML
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
def dashboard():
    html_path = os.path.join(os.path.dirname(__file__), "index.html")
    with open(html_path, encoding="utf-8") as f:
        return f.read()
