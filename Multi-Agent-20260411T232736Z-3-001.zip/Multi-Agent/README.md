# 🤖 Multi-Agent System

Sistema de 3 agentes especializados que se comunican mediante una API REST central.

## Arquitectura

```
[Agent 1 - Kaggle Scraper]  →  POST /datasets/upload
          ↓
[API Central - localhost:8000]  ←→  SQLite3
          ↓
[Agent 2 - SQL Learner]     →  NL → SQL → Insights
          ↓
[Agent 3 - Visualizer]      →  Gráficas + Explicaciones HTML
```

## Estructura del proyecto

```
Multi-Agent/
├── api/
│   ├── __init__.py
│   ├── main.py          ← FastAPI con todos los endpoints
│   └── database.py      ← SQLite3 init y esquema
├── agent2_sql_learner/
│   ├── __init__.py
│   ├── main.py          ← CLI interactivo
│   ├── groq_client.py   ← NL→SQL, insights, sugerencias
│   ├── sql_engine.py    ← Ejecución SQL, train/test split
│   ├── cache.py         ← Cache SQLite de queries
│   └── insights.py      ← Estadísticas y persistencia en API
├── start_api.py         ← Arranca la API Central
├── start_agent2.py      ← Arranca el Agent 2
├── requirements.txt
└── .env
```

## Instalación

```bash
pip install -r requirements.txt
```

## Uso

### 1. Arrancar la API Central (puerto 8000)
```bash
python start_api.py
```
Documentación automática: http://localhost:8000/docs

### 2. Arrancar el Agent 2 (en otra terminal)
```bash
python start_agent2.py
```

## Endpoints de la API Central

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/datasets/upload` | Subir CSV + metadata |
| GET | `/datasets/list` | Listar datasets |
| GET | `/datasets/{id}/data` | Datos del dataset |
| GET | `/datasets/{id}/schema` | Esquema del dataset |
| POST | `/queries/run` | Guardar resultado de query |
| GET | `/queries/results/{id}` | Resultado por ID |
| GET | `/queries/history` | Historial de queries |
| POST | `/insights/save` | Guardar insight |
| GET | `/insights/latest` | Últimos insights |
| POST | `/cache/save` | Guardar en cache |
| GET | `/cache/get/{key}` | Consultar cache |
| GET | `/cache/hits` | Top queries cacheadas |

## Configuración (.env)

```env
GROQ_API_KEY=gsk_...
GROQ_MODEL=llama-3.3-70b-versatile
API_BASE_URL=http://localhost:8000
DATABASE_PATH=./data/multiagent.db
DATASETS_DIR=./data/datasets
CACHE_DB=./data/cache.db
PORT=8000
```

## Comandos en el Agent 2

| Comando | Descripción |
|---------|-------------|
| `[cualquier pregunta]` | Traduce a SQL y ejecuta |
| `sugerir` | El LLM sugiere 5 preguntas para el dataset |
| `cache` | Ver las queries más frecuentes |
| `historial` | Ver el historial de la API Central |
| `salir` | Cerrar el agente |

## Tecnologías

- **API**: FastAPI + SQLite3 (built-in)
- **LLM**: Groq API (`llama-3.3-70b-versatile`)
- **Terminal**: Rich (tablas, colores, progress bars)
- **Datos**: Pandas
